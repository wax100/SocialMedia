----------------------
Social Media
----------------------
Version: 1.1.1
Author: Oene Tjeerd de Bruin
Contact: modx@oetzie.nl
----------------------

This use this component the user needs to have the "socialmedia" permissions.