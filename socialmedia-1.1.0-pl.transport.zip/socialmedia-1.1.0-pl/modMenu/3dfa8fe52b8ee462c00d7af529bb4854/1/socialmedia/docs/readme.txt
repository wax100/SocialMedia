----------------------
Social Media
----------------------
Version: 1.1.0
Author: Oene Tjeerd de Bruin
Contact: info@oetzie.nl
----------------------

This use this component the user needs to have the "socialmedia" permissions.